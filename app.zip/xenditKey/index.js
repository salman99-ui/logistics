const tokenXendit = Buffer.from(
  "xnd_development_tiBn1LTcues67D1JnQ0hwRgHIgsb8C3NZgYn8yOgxW0YgTiZySKGImr38uSnUM"
).toString("base64");

module.exports = tokenXendit;
